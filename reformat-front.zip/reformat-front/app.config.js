/* eslint-env node -- webpack is node env */
/* eslint max-len: "off" -- webpack is node env */

const ENV = require('./app.env');

module.exports = {
    TITLE: 'Компания Reformat',
    SHORT_NAME: 'Reformat',
    DESCRIPTION: 'Reformat - Мы помогаем бизнесу развиваться, осваивать новые технологии и подходы',
    PUBLIC_PATH: '/', // for relative use './'
    USE_FAVICONS: true,
    LANGUAGE: 'ru',
    START_URL: '/?utm_source=app_manifest',
    THEME_COLOR: '#fff',
    BACKGROUND_COLOR: '#fff',
    HTML_PRETTY: true,
    SENTRY: {
        dsn: '',
        ignoreErrors: [],
        blacklistUrls: [],
        whitelistUrls: [],
    },
    JQUERY: true,
    LINT_FIX: true,
    WEBP: true,
    AVIF: true,
    BROTLI: true,
    GZIP: true,
    STYLELINT: true,
    ESLINT: true,
};

module.exports.ENV = ENV;
