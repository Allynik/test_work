/* eslint 'compat/compat': 'off' -- useless for polyfill */

// for polyfill use only require
require('focus-visible');
