// for polyfill use only require
const { default: focusWithin } = require('focus-within');

focusWithin(document);
