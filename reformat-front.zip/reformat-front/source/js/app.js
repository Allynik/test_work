/* global VERBOSE BANNER_STRING */

import barba from '@barba/core';

import '~/components/bootstrap';
import '~/components/viewport-height';
import '~/components/scrollbar-width';

import transitions from '~/transitions/index';
import components from '~/components/index';
import AbstractApp from '~/components/app';

class App extends AbstractApp {
    init() {
        console.log(BANNER_STRING);
        document.documentElement.classList.add('ready-js');
        document.documentElement.classList.remove('is-scroll-unknown');

        super.init();

        this.initBarba();
        this.initHooks();
        this.initEvents();
        this.initTransitions();
        this.initCounters();
    }

    initBarba() {
        barba.init({
            debug: VERBOSE,
            logLevel: VERBOSE ? 'debug' : 'off',
            transitions,
        });
    }

    initHooks() {
        barba.hooks.all.forEach((value) => {
            barba.hooks[value](function barbaHook(data) {
                // eslint-disable-next-line no-invalid-this -- its ok for function wrap
                data.hook = this;
                if (VERBOSE) {
                    console.log(`[barba.hooks] ${value}`, data);
                }
                const event = new CustomEvent(`barba.${value}`, { detail: data });
                window.dispatchEvent(event);
            });
        });
    }

    initCounters() {
        if (VERBOSE) {
            console.log('[app] init counters');
        }

        window.addEventListener('barba.after', () => this.hitCounters());
    }

    hitCounters() {
        // google analitycs
        if (typeof window.ga !== 'undefined') {
            if (VERBOSE) {
                console.log('[app] hit counters ga', window.ga);
            }
            window.ga('set', 'page', document.location.pathname);
            window.ga('send', 'pageview');
        }

        // yandex metrika
        for (const key in window) { // eslint-disable-line no-restricted-syntax -- it`s ok
            if (key.indexOf('yaCounter') === 0 && window[key] && window[key].hit) {
                if (VERBOSE) {
                    console.log('[app] hit counters ya', key);
                }
                window[key].hit(document.location.href, { title: document.title, referer: document.referrer });
            }
        }
    }

    initTransitions() {
        window.addEventListener('barba.before', () => {
            // lock transitions
            document.documentElement.classList.add('is-barba-transitioning');
        });
        window.addEventListener('barba.after', () => {
            // unlock transitions
            document.documentElement.classList.remove('is-barba-transitioning');
        });
    }

    initEvents() {
        window.addEventListener('barba.leave', (event) => {
            this.destroyScope(event.detail.current.container);
        });
        window.addEventListener('barba.enter', (event) => {
            this.initScope(event.detail.next.container);
        });
    }
}

const app = new App({ components });
if (VERBOSE) {
    window.$app = app;
    console.log('[app]', app);
}

const domReady = () => {
    document.removeEventListener('DOMContentLoaded', domReady);
    app.init();
};
document.addEventListener('DOMContentLoaded', domReady);

export default app;
