import createDocument from '~/utils/create-document';
import createElement from '~/utils/create-element';
import isSelector from '~/utils/is-selector';

export default { createDocument, isSelector, createElement };
