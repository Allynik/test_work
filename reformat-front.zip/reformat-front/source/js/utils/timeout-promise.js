export default function timeoutPromise(delay) {
    // eslint-disable-next-line no-promise-executor-return -- its ok
    return new Promise((resolve) => setTimeout(resolve, delay));
}
