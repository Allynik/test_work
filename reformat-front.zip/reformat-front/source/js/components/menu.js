import gsap from 'gsap';

import AbstractComponent from '~/components/abstract';

export default class Menu extends AbstractComponent {
    constructor(options) {
        super(options);
        this.onClick = this.onClick.bind(this);
        this.onBarbaBefore = this.onBarbaBefore.bind(this);
        this.lockTransition = false;
    }

    init() {
        this.dialogElement = document.querySelector('.mobile-menu');
        this.element.addEventListener('click', this.onClick);
        window.addEventListener('barba.before', this.onBarbaBefore);
    }

    destroy() {
        this.element.removeEventListener('click', this.onClick);
        window.removeEventListener('barba.before', this.onBarbaBefore);
    }

    get active() {
        return document.body.classList.contains('is-menu-open');
    }

    open() {
        if (this.active || this.lockTransition) return;

        const timeline = gsap.timeline({
            onStart: () => {
                this.lockTransition = true;
                document.body.classList.add('is-menu-open');
                this.app.get('Scroll').stop();

                this.dialogElement.removeAttribute('aria-hidden');
                this.dialogElement.setAttribute('aria-modal', true);
                this.dialogElement.setAttribute('role', 'dialog');
            },
            onComplete: () => {
                this.lockTransition = false;
                gsap.set(this.dialogElement, { clearProps: 'all' });

                this.element.blur();
                this.dialogElement.focus();
            },
        });

        timeline.add(gsap.set(this.dialogElement, {
            display: 'block',
        })).from(this.dialogElement, {
            ease: 'power4.out',
            duration: 0.6,
            scale: 0.9,
            opacity: 0,
        });
    }

    close() {
        if (!this.active || this.lockTransition) return;

        const timeline = gsap.timeline({
            onStart: () => {
                this.lockTransition = true;
                this.app.get('Scroll').start();

                this.dialogElement.setAttribute('aria-hidden', true);
                this.dialogElement.removeAttribute('aria-modal');
                this.dialogElement.removeAttribute('role');
            },
            onComplete: () => {
                this.lockTransition = false;

                document.body.classList.remove('is-menu-open');
                gsap.set(this.dialogElement, { clearProps: 'all' });

                this.element.blur();
            },
        });

        timeline.to(this.dialogElement, {
            ease: 'power4.in',
            duration: 0.6,
            scale: 0.9,
            opacity: 0,
        });
    }

    toggle() {
        if (this.active) {
            this.close();
        } else {
            this.open();
        }
    }

    onClick(event) {
        event.preventDefault();
        this.toggle();
    }

    onBarbaBefore() {
        this.close();
    }
}
