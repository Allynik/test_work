import gsap from 'gsap';

import AbstractComponent from '~/components/abstract';

export default class PopUp extends AbstractComponent {
    constructor(options) {
        super(options);
        this.onClickToggle = this.onClickToggle.bind(this);
        this.onClickClose = this.onClickClose.bind(this);
        this.onClickBackdrop = this.onClickBackdrop.bind(this);
        this.lockTransition = false;
    }

    init() {
        this.toggleButton = this.selector('[data-popup="toggle"]');
        this.closeButton = this.selector('[data-popup="close"]');
        this.innerElement = this.selector('[data-popup="inner"]');
        this.dialogElement = this.selector('[data-popup="dialog"]');
        this.backdropElement = this.selector('[data-popup="backdrop"]');

        this.toggleButton.addEventListener('click', this.onClickToggle);
        this.closeButton.addEventListener('click', this.onClickClose);
        this.backdropElement.addEventListener('click', this.onClickBackdrop);
    }

    destroy() {
        this.toggleButton.removeEventListener('click', this.onClickToggle);
        this.closeButton.removeEventListener('click', this.onClickClose);
        this.backdropElement.removeEventListener('click', this.onClickBackdrop);
    }

    get active() {
        return this.element.classList.contains('is-active');
    }

    open() {
        if (this.active || this.lockTransition) return;

        const timeline = gsap.timeline({
            onStart: () => {
                this.lockTransition = true;
                this.element.classList.add('is-active');

                document.body.classList.add('is-popup-open');
                this.app.get('Scroll').stop();

                this.dialogElement.removeAttribute('aria-hidden');
                this.dialogElement.setAttribute('aria-modal', true);
                this.dialogElement.setAttribute('role', 'dialog');
            },
            onComplete: () => {
                this.lockTransition = false;
                gsap.set(this.dialogElement, { clearProps: 'all' });
                gsap.set(this.innerElement, { clearProps: 'all' });

                this.element.blur();
                this.dialogElement.focus();
            },
        });
        timeline.add(gsap.set(this.innerElement, {
            opacity: 0,
            x: 50,
        })).from(this.dialogElement, {
            ease: 'power4.out',
            duration: 0.6,
            opacity: 0,
            height: 0,
            width: 0,
        }, 0).to(this.innerElement, {
            duration: 0.6,
            opacity: 1,
            x: 0,
        }, 0.4);
    }

    close() {
        if (!this.active || this.lockTransition) return;

        const timeline = gsap.timeline({
            onStart: () => {
                this.lockTransition = true;

                document.body.classList.remove('is-popup-open');
                this.app.get('Scroll').start();

                this.dialogElement.setAttribute('aria-hidden', true);
                this.dialogElement.removeAttribute('aria-modal');
                this.dialogElement.removeAttribute('role');
            },
            onComplete: () => {
                this.lockTransition = false;
                this.element.classList.remove('is-active');

                gsap.set(this.innerElement, { clearProps: 'all' });
                gsap.set(this.dialogElement, { clearProps: 'all' });

                this.element.blur();
            },
        });
        timeline.to(this.innerElement, {
            duration: 0.4,
            opacity: 1,
        }, 0).to(this.dialogElement, {
            ease: 'power4.in',
            duration: 0.6,
            opacity: 0,
            height: 0,
            width: 0,
        }, 0.4);
    }

    toggle() {
        if (this.active) {
            this.close();
        } else {
            this.open();
        }
    }

    onClickToggle(event) {
        event.preventDefault();
        this.toggle();
    }

    onClickClose(event) {
        event.preventDefault();
        this.close();
    }

    onClickBackdrop(event) {
        event.preventDefault();
        this.close();
    }
}
