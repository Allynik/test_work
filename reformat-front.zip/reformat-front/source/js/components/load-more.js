import createElement from '~/utils/create-element';
import timeoutPromise from '~/utils/timeout-promise';
import AbstractComponent from '~/components/abstract';

const DELAY_TIME = 1000;

export default class LoadMore extends AbstractComponent {
    constructor(options) {
        super(options);
        this.onClick = this.onClick.bind(this);
    }

    init() {
        this.element.addEventListener('click', this.onClick);
        this.element.setAttribute('href', '#');
    }

    destroy() {
        this.element.removeEventListener('click', this.onClick);
    }

    onClick(event) {
        event.preventDefault();

        const url = this.element.getAttribute('data-load-more');
        if (!url) return;

        const selector = this.element.getAttribute('data-load-more-target');
        if (!selector) return;

        const container = this.element.closest('[data-barba="container"]');
        const target = container.querySelector(selector);
        if (!target) return;

        this.element.classList.add('is-loading');
        this.element.classList.remove('is-loading-error');
        this.element.setAttribute('disabled', true);

        let responseTime = (new Date()).getTime();
        fetch(url).then((response) => {
            responseTime = (new Date()).getTime() - responseTime;
            if (!response.ok) {
                throw new Error(`${response.status}: ${response.statusText}`);
            }
            return response.text();
        }).then(async (result) => {
            await timeoutPromise(DELAY_TIME);
            this.element.classList.remove('is-loading');
            this.element.removeAttribute('disabled');

            const element = createElement(result);
            [...element.childNodes].forEach((child) => target.appendChild(child));

            if (element.getAttribute('data-load-more')) {
                this.element.setAttribute('data-load-more', element.getAttribute('data-load-more'));
            } else {
                this.element.setAttribute('data-load-more', '');
                this.element.style.display = 'none';
            }

            this.app.initScope(target);
            this.app.get('Scroll').update();
        }).catch((error) => {
            console.error('[load-more]', error);

            this.element.classList.add('is-loading-error');
            this.element.removeAttribute('disabled');
        });
    }
}
