import rand from '~/utils/random';
import AbstractComponent from '~/components/abstract';

export default class DecorWrapper extends AbstractComponent {
    init() {
        this.element.querySelectorAll('.decor').forEach((decor) => {
            decor.classList.add('decor--animation');

            decor.style.setProperty('--decor-x-1', rand(-1, 1));
            decor.style.setProperty('--decor-y-1', rand(-1, 1));

            decor.style.setProperty('--decor-x-2', rand(-1, 1));
            decor.style.setProperty('--decor-y-2', rand(-1, 1));

            decor.style.setProperty('--decor-x-3', rand(-1, 1));
            decor.style.setProperty('--decor-y-3', rand(-1, 1));

            decor.style.setProperty('--decor-x-4', rand(-1, 1));
            decor.style.setProperty('--decor-y-4', rand(-1, 1));

            decor.style.setProperty('--decor-x-5', rand(-1, 1));
            decor.style.setProperty('--decor-y-5', rand(-1, 1));
        });
    }

    destroy() {
        //
    }
}
