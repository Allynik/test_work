import isFunction from '~/utils/is-function';
import timeoutPromise from '~/utils/timeout-promise';
import AbstractComponent from '~/components/abstract';

const DELAY_TIME = 1000;

export default class FormSubmit extends AbstractComponent {
    constructor(options) {
        super(options);
        this.onSubmit = this.onSubmit.bind(this);
    }

    init() {
        this.formAlert = this.element.querySelector('.form-alert');
        this.buttonSubmit = this.element.querySelector('button[type=submit]');
        if (this.element.hasAttribute('onsubmit')) {
            this.element.dataset.onSubmitAttr = this.element.getAttribute('onsubmit');
            this.element.removeAttribute('onsubmit');
        }
        this.element.addEventListener('submit', this.onSubmit);
    }

    onSubmit(event) {
        if (!this.element.checkValidity()) return;
        event.preventDefault();

        const url = this.element.getAttribute('action');
        const formData = new FormData(this.element);

        this.element.classList.add('is-loading');
        this.element.classList.remove('is-loading-error');
        this.element.classList.remove('is-loading-success');

        this.formAlert.innerHTML = '';
        this.formAlert.classList.remove('show');

        let onSubmitHandler = this.element.dataset.onSubmitAttr;
        if (onSubmitHandler && typeof onSubmitHandler === 'string') {
            // eslint-disable-next-line no-eval, no-new-func -- onsubmit attribute is string, but we need function
            onSubmitHandler = new Function('event', onSubmitHandler);
        }
        if (onSubmitHandler && isFunction(onSubmitHandler)) {
            try {
                const onSubmitResult = onSubmitHandler.call(this.element, event);
                console.log('[form-submit] onFormSubmit', { onsubmit: onSubmitHandler, result: onSubmitResult });
            } catch (onSubmitError) {
                console.error('[form-submit] onFormSubmit', { onsubmit: onSubmitHandler, error: onSubmitError });
            }
        }

        let responseTime = (new Date()).getTime();
        fetch(url, {
            method: 'POST',
            body: formData,
        }).then((response) => {
            responseTime = (new Date()).getTime() - responseTime;
            if (!response.ok) {
                throw new Error(`${response.status}: ${response.statusText}`);
            }
            return response.json();
        }).then(async (result) => {
            await timeoutPromise(DELAY_TIME);
            this.element.classList.remove('is-loading');

            if (result.error) {
                this.element.classList.add('is-loading-error');

                this.formAlert.innerHTML = result.error;
                this.formAlert.classList.add('show');
            } else if (result.message) {
                this.element.classList.add('is-loading-success');

                this.formAlert.innerHTML = result.message;
                this.formAlert.classList.add('show');
                this.element.reset();
            }

            console.log('[form-submit]', result);
        }).catch((error) => {
            console.error('[form-submit]', error);

            this.element.classList.add('is-loading-error');
        });
    }

    destroy() {
        this.buttonSubmit = null;
    }
}
