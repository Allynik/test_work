import nextTick from '~/utils/next-tick';
import AbstractComponent from '~/components/abstract';
import LocomotiveScroll from 'locomotive-scroll/src/locomotive-scroll';

const OFFSET_GUTTER = 15;

const normalizeLocation = (loc) => `${loc.origin + loc.pathname}?${loc.search}`;
const isExternalLocation = (loc) => normalizeLocation(document.location) !== normalizeLocation(loc);

const HASH_OPTIONS = {
    '#top': { duration: 0, disableLerp: true },
};

export default class PageScroll extends AbstractComponent {
    constructor(options) {
        super(options);

        this.scroll = { x: 0, y: 0 };
        this.limit = { x: document.documentElement.offsetWidth, y: document.documentElement.offsetHeight };
        this.diff = { x: 0, y: 0 };

        this.onBarbaAfter = this.onBarbaAfter.bind(this);
        this.onBarbaBefore = this.onBarbaBefore.bind(this);
        this.onBarbaAfterEnter = this.onBarbaAfterEnter.bind(this);

        this.onScroll = this.onScroll.bind(this);
        this.onClick = this.onClick.bind(this);
    }

    init() {
        this.header = document.querySelector('.header--main');
        this.headerRect = this.header.getBoundingClientRect();

        this.container = this.element.querySelector('.barba-container');
        this.initContainer(this.container);

        this.instance = new LocomotiveScroll({
            el: this.element,
            initPosition: { x: 0, y: 0 },
            offset: [50, 0],
            scrollFromAnywhere: true,
            smooth: true,
            smartphone: { smooth: false },
            tablet: { smooth: false, breakpoint: 992 },
            repeat: true,
        });

        this.instance.on('scroll', this.onScroll);

        window.addEventListener('barba.after', this.onBarbaAfter);
        window.addEventListener('barba.before', this.onBarbaBefore);
        window.addEventListener('barba.afterEnter', this.onBarbaAfterEnter);

        document.addEventListener('click', this.onClick);

        if (document.location.hash !== '' && document.location.hash !== '#') {
            this.scrollTo(document.location.hash, {
                duration: 0,
                disableLerp: true,
                offset: -this.headerOffset,
            });
        }
    }

    destroy() {
        this.intance.destroy();

        window.removeEventListener('barba.after', this.onBarbaAfter);
        window.removeEventListener('barba.before', this.onBarbaBefore);
        window.removeEventListener('barba.afterEnter', this.onBarbaAfterEnter);

        document.removeEventListener('click', this.onClick);
    }

    initContainer(container) {
        container.querySelectorAll(':scope > *').forEach((section) => {
            if (!section.hasAttribute('data-scroll-ignore')) {
                section.setAttribute('data-scroll-section', '');
            }
        });
    }

    onScroll({ limit, scroll }) {
        this.diff.x = scroll.x - this.scroll.x;
        this.diff.y = scroll.y - this.scroll.y;

        if (this.diff.y > 0) {
            document.documentElement.setAttribute('data-scroll-direction', 'down');
        } else if (this.diff.y < 0) {
            document.documentElement.setAttribute('data-scroll-direction', 'up');
        } else {
            document.documentElement.removeAttribute('data-scroll-direction');
        }

        this.scroll.x = scroll.x;
        this.scroll.y = scroll.y;

        this.limit.x = limit.x;
        this.limit.y = limit.y;

        this.trigger('scroll', {
            target: this,
            scroll: this.scroll,
            limit: this.limit,
        });

        const progress = (scroll.y / limit.y).toFixed(3);
        document.documentElement.style.setProperty('--scroll-progress', progress);
    }

    onBarbaAfter({ detail: { trigger } }) {
        this.update();
        if (trigger.matches && trigger.matches('a') && trigger.hash !== '' && trigger.hash !== '#') {
            this.scrollTo(trigger.hash, {
                offset: -this.headerOffset,
                ...(trigger.hash in HASH_OPTIONS ? HASH_OPTIONS[trigger.hash] : {}),
            });
        }
    }

    onBarbaAfterEnter(event) {
        this.container = event.detail.next.container;
        this.initContainer(this.container);

        this.start();
        this.update();
    }

    onBarbaBefore() {
        this.resetScrollPosition();
        this.stop();
    }

    onClick(event) {
        const currentTarget = event.target.closest('a');
        if (!currentTarget) return;
        if (isExternalLocation(currentTarget)) return;
        if (currentTarget.hash !== '' && currentTarget.hash !== '#') {
            event.preventDefault();
            this.scrollTo(currentTarget.hash, { offset: -this.headerOffset });
            window.history.pushState({}, document.title, currentTarget.href);
            currentTarget.blur();
        }
    }

    async update() {
        // wait side effects changes
        await nextTick();

        this.instance.update();
        document.documentElement.classList.remove('has-scroll-scrolling');
    }

    stop() {
        this.instance.stop();
        document.documentElement.classList.add('no-scroll');
    }

    start() {
        this.instance.start();
        document.documentElement.classList.remove('no-scroll', 'has-scroll-scrolling');
    }

    scrollTo(target, options = {}) {
        return this.instance.scrollTo(target, options);
    }

    disableSmoothScroll() {
        document.documentElement.classList.add('no-smooth-scroll');
    }

    enableSmoothScroll() {
        document.documentElement.classList.remove('no-smooth-scroll');
    }

    resetScrollPosition() {
        this.disableSmoothScroll();
        this.instance.scrollTo(0, {
            duration: 0,
            disableLerp: true,
            callback: () => this.enableSmoothScroll(),
        });
    }

    get headerOffset() {
        return this.headerRect.height + OFFSET_GUTTER;
    }
}
