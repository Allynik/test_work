import AbstractComponent from '~/components/abstract';

export default class YaShare2 extends AbstractComponent {
    init() {
        this.initScript();
    }

    initScript() {
        if (!this.loaded) {
            const script = document.createElement('script');
            script.src = 'https://yastatic.net/share2/share.js';
            script.async = true;
            script.onload = () => this.onLoadScript();
            document.body.appendChild(script);
        }
    }

    onLoadScript() {
        if (this.loaded) {
            this.element.classList.add('ya-share2');
            this.instance = window.Ya.share2(this.element);
        }
    }

    get loaded() {
        return (window.Ya && window.Ya.share2);
    }

    destroy() {
        if (this.instance) {
            this.instance.destroy();
        }
    }
}
