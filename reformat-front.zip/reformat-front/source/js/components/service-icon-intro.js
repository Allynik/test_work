import rand from '~/utils/random';
import AbstractComponent from '~/components/abstract';

export default class ServiceIconIntro extends AbstractComponent {
    init() {
        const selector = 'svg > rect, svg > circle, svg > ellipse, svg > line, svg > polyline, svg > polygon, svg > path, svg > g';
        this.element.querySelectorAll(selector).forEach((item) => {
            const transitionDelay = rand(0, 1).toFixed(4);
            const transformOriginX = rand(0, 100).toFixed(4);
            const transformOriginY = rand(0, 100).toFixed(4);
            const style = `transition-delay: ${transitionDelay}s; transform-origin: ${transformOriginX}% ${transformOriginY}%;`;
            item.outerHTML = `<g class="js-service-icon-group" style="${style}">${item.outerHTML}</g>`;
        });
    }

    destroy() {
        //
    }
}
