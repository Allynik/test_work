import AbstractComponent from '~/components/abstract';

const SCROLL_GAP = 15;

export default class Header extends AbstractComponent {
    constructor(options) {
        super(options);
        this.onScrollNative = this.onScrollNative.bind(this);
        this.onScrollVirtual = this.onScrollVirtual.bind(this);
        this.onBarbaBefore = this.onBarbaBefore.bind(this);
        this.onBarbaAfter = this.onBarbaAfter.bind(this);
        this.lastScrollTop = document.documentElement.scrollTop;
    }

    init() {
        window.addEventListener('scroll', this.onScrollNative);
        this.app.on('Scroll', 'scroll', this.onScrollVirtual);
        window.addEventListener('barba.before', this.onBarbaBefore);
        window.addEventListener('barba.after', this.onBarbaAfter);
    }

    destroy() {
        window.removeEventListener('scroll', this.onScrollNative);
        this.app.off('Scroll', 'scroll', this.onScrollVirtual);
        window.removeEventListener('barba.before', this.onBarbaBefore);
        window.removeEventListener('barba.after', this.onBarbaAfter);
    }

    onScrollNative() {
        this.updateScrollTop(document.documentElement.scrollTop);
    }

    onScrollVirtual(event) {
        this.updateScrollTop(event.detail.scroll.y);
    }

    updateScrollTop(scrollTop) {
        if (scrollTop > SCROLL_GAP) {
            document.body.classList.add('is-scrolled-down');
        } else {
            document.body.classList.remove('is-scrolled-down');
        }
        if (this.lastScrollTop < scrollTop) {
            document.body.classList.add('is-header-hide');
        } else {
            document.body.classList.remove('is-header-hide');
        }
        this.lastScrollTop = scrollTop;
    }

    reset() {
        document.body.classList.remove('is-header-hide');
        document.body.classList.remove('is-scrolled-down');
    }

    onBarbaBefore() {
        this.reset();
    }

    onBarbaAfter() {
        this.reset();
    }
}
