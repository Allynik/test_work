import Menu from '~/components/menu';
import Header from '~/components/header';
import Scroll from '~/components/scroll';
import LoadMore from '~/components/load-more';
import PopUp from '~/components/popup';
import Questions from '~/components/questions';
import Modal from '~/components/modal';
import YaShare2 from '~/components/ya-share2';
import DecorWrapper from '~/components/decor-wrapper';
import ServiceIconIntro from '~/components/service-icon-intro';
import FormSubmit from '~/components/form-submit';

export default {
    Menu, Header, Scroll, LoadMore, PopUp, Questions, Modal, YaShare2, DecorWrapper, ServiceIconIntro, FormSubmit,
};
