import AbstractComponent from '~/components/abstract';

export default class Questions extends AbstractComponent {
    constructor(options) {
        super(options);
        this.onClickToggle = this.onClickToggle.bind(this);
    }

    init() {
        this.toggleButton = this.selector('[data-questions="toggle"]');
        this.toggleButton.addEventListener('click', this.onClickToggle);
    }

    destroy() {
        this.toggleButton.removeEventListener('click', this.onClickToggle);
    }

    get active() {
        return this.element.classList.contains('is-active');
    }

    open() {
        if (this.active) return;

        this.element.classList.add('is-active');
        document.body.classList.add('is-questions-open');
        this.app.get('Scroll').update();
    }

    close() {
        if (!this.active) return;

        this.element.classList.remove('is-active');
        document.body.classList.remove('is-questions-open');
        this.app.get('Scroll').update();
    }

    toggle() {
        if (this.active) {
            this.close();
        } else {
            this.open();
        }
    }

    onClickToggle(event) {
        event.preventDefault();
        this.open();
    }
}
