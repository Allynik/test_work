import gsap from 'gsap';

import AbstractComponent from '~/components/abstract';

export default class Modal extends AbstractComponent {
    constructor(options) {
        super(options);
        this.onClickToggle = this.onClickToggle.bind(this);
        this.onClickClose = this.onClickClose.bind(this);
        this.onBarbaBefore = this.onBarbaBefore.bind(this);
        this.lockTransition = false;
    }

    init() {
        const selector = this.element.getAttribute('href') || this.element.getAttribute('data-modal');
        this.dialogElement = document.querySelector(selector);
        this.bodyElement = this.dialogElement.querySelector('[data-modal="body"]');
        this.transitionElement = this.dialogElement.querySelector('[data-modal="transition"]');
        this.closeButton = this.dialogElement.querySelector('[data-modal="close"]');

        this.element.addEventListener('click', this.onClickToggle);
        this.closeButton.addEventListener('click', this.onClickClose);
        window.addEventListener('barba.before', this.onBarbaBefore);
    }

    destroy() {
        this.element.removeEventListener('click', this.onClick);
        window.removeEventListener('barba.before', this.onBarbaBefore);
    }

    get active() {
        return this.dialogElement.classList.contains('is-active');
    }

    open() {
        if (this.active || this.lockTransition) return;

        const timeline = gsap.timeline({
            onStart: () => {
                this.lockTransition = true;
                this.dialogElement.classList.add('is-active');

                document.body.classList.add('is-modal-popup-open');
                this.app.get('Scroll').stop();

                this.dialogElement.removeAttribute('aria-hidden');
                this.dialogElement.setAttribute('aria-modal', true);
                this.dialogElement.setAttribute('role', 'dialog');
            },
            onComplete: () => {
                this.lockTransition = false;
                gsap.set(this.bodyElement, { clearProps: 'all' });
                gsap.set(this.transitionElement, { clearProps: 'all' });

                this.element.blur();
                this.dialogElement.focus();
            },
        });

        timeline.add(gsap.set(this.transitionElement, {
            display: 'block',
            xPercent: 0,
        })).add(gsap.set(this.bodyElement, {
            overflow: 'hidden',
        })).to(this.transitionElement, {
            ease: 'power4.inOut',
            duration: 1,
            xPercent: 100,
        }).to(this.transitionElement, {
            duration: 0.3,
            opacity: 0,
        });
    }

    close() {
        if (!this.active || this.lockTransition) return;

        const timeline = gsap.timeline({
            onStart: () => {
                this.lockTransition = true;

                this.dialogElement.setAttribute('aria-hidden', true);
                this.dialogElement.removeAttribute('aria-modal');
                this.dialogElement.removeAttribute('role');
            },
            onComplete: () => {
                this.lockTransition = false;
                this.dialogElement.classList.remove('is-active');
                document.body.classList.remove('is-modal-popup-open');
                this.app.get('Scroll').start();

                gsap.set(this.bodyElement, { clearProps: 'all' });
                gsap.set(this.transitionElement, { clearProps: 'all' });

                this.element.blur();
            },
        });

        timeline.add(gsap.set(this.transitionElement, {
            display: 'block',
            xPercent: 100,
        })).add(gsap.set(this.bodyElement, {
            overflow: 'hidden',
        })).to(this.transitionElement, {
            ease: 'power4.inOut',
            duration: 0.6,
            xPercent: 0,
        }).to(this.bodyElement, {
            duration: 0.3,
            opacity: 0,
        });
    }

    toggle() {
        if (this.active) {
            this.close();
        } else {
            this.open();
        }
    }

    onClickToggle(event) {
        event.preventDefault();
        this.toggle();
    }

    onClickClose(event) {
        event.preventDefault();
        this.close();
    }

    onBarbaBefore() {
        this.close();
    }
}
