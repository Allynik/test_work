import gsap from 'gsap';

function leaveAnimation(container) {
    const element = container.querySelector('.page-transition');
    const timeline = gsap.timeline({
        onComplete: () => {
            container.style.display = 'none';
        },
    });

    timeline.add(gsap.set(element, {
        xPercent: -115,
        display: 'block',
        skewX: 15,
    })).add(gsap.to(element, {
        duration: 1,
        xPercent: 0,
        ease: 'power4.inOut',
        skewX: 0,
    }));

    return timeline.then();
}

function enterAnimation(container) {
    const element = container.querySelector('.page-transition');
    const timeline = gsap.timeline();

    timeline.add(gsap.set(element, {
        xPercent: 0,
        display: 'block',
    })).to(element, {
        duration: 0.6,
        xPercent: 100,
        ease: 'power4.inOut',
    }).set(element, {
        display: 'none',
    });

    return timeline.then();
}

function onceAnimation() {
    return new Promise((resolve) => {
        resolve();
    });
}

const DefaultTransition = {
    sync: false,
    name: 'default-transition',

    once({ next }) {
        document.documentElement.classList.add('is-transition-once');
        next.container.classList.add('is-container-once');
        return onceAnimation();
    },

    leave({ current }) {
        current.container.classList.add('is-container-once');
        return leaveAnimation(current.container);
    },

    enter({ next }) {
        next.container.classList.add('is-container-enter');
        return enterAnimation(next.container);
    },
};

export default DefaultTransition;
