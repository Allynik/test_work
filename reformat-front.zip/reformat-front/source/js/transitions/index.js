/* global VERBOSE */
import DefaultTransition from './default';

const transitions = [
    DefaultTransition,
];

if (VERBOSE) {
    console.log('[transitions] init', transitions);

    window.$transitions = transitions;
}

export default transitions;
