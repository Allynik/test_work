/* eslint-env node -- webpack is node env */
/* eslint max-len: "off" -- useless for data file */

module.exports = {
};
